/*
  # Forge Atlas Community Schema

  Creates the core community tables enabling:
  - User-submitted forum posts with categories and Atlas AI fallback
  - Post reactions (upvotes) with localStorage fingerprint deduplication
  - Arena match votes and reactions (vote/react/share only, no comments)
  - Swarm mission support votes and user prompt submissions
  - Prompt generator submissions for swarm teams

  ## New Tables
  - `forum_posts` — user-submitted discussion threads with author alias, category, body
  - `forum_reactions` — per-post upvotes keyed by anonymous session fingerprint
  - `arena_votes` — per-match votes (left/right fighter), one per session
  - `arena_reactions` — emoji reactions on arena matches
  - `swarm_supports` — per-mission support votes, one per session
  - `swarm_prompts` — user-submitted team prompts for swarm missions
  - `site_stats` — global counters (views, total votes) for self-sustaining dashboards

  ## Security
  - RLS enabled on all tables
  - Anonymous read is allowed for all public community data
  - Writes require a non-empty session_id (browser-generated fingerprint)
  - No auth.uid() required — site is static/anonymous-first
*/

-- ── FORUM POSTS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS forum_posts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_alias  text NOT NULL DEFAULT 'Anonymous Operator',
  category      text NOT NULL DEFAULT 'discussion'
                  CHECK (category IN ('discussion','showcase','strategy','news')),
  title         text NOT NULL CHECK (char_length(title) BETWEEN 5 AND 160),
  body          text NOT NULL CHECK (char_length(body) BETWEEN 20 AND 4000),
  reaction_count integer NOT NULL DEFAULT 0,
  reply_count    integer NOT NULL DEFAULT 0,
  is_ai_post     boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read forum posts"
  ON forum_posts FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert forum posts"
  ON forum_posts FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(title) >= 5 AND char_length(body) >= 20);

-- ── FORUM REACTIONS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS forum_reactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id     uuid NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  session_id  text NOT NULL CHECK (char_length(session_id) >= 8),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE(post_id, session_id)
);

ALTER TABLE forum_reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read forum reactions"
  ON forum_reactions FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert forum reactions"
  ON forum_reactions FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(session_id) >= 8);

-- ── ARENA VOTES ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS arena_votes (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_key   text NOT NULL,
  side        text NOT NULL CHECK (side IN ('left','right')),
  session_id  text NOT NULL CHECK (char_length(session_id) >= 8),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE(match_key, session_id)
);

ALTER TABLE arena_votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read arena votes"
  ON arena_votes FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert arena votes"
  ON arena_votes FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(session_id) >= 8);

-- ── ARENA REACTIONS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS arena_reactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_key   text NOT NULL,
  emoji       text NOT NULL DEFAULT 'fire' CHECK (emoji IN ('fire','mind_blown','👑','⚡','🎯')),
  session_id  text NOT NULL CHECK (char_length(session_id) >= 8),
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE arena_reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read arena reactions"
  ON arena_reactions FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert arena reactions"
  ON arena_reactions FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(session_id) >= 8);

-- ── SWARM SUPPORTS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS swarm_supports (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mission_key  text NOT NULL,
  session_id   text NOT NULL CHECK (char_length(session_id) >= 8),
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE(mission_key, session_id)
);

ALTER TABLE swarm_supports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read swarm supports"
  ON swarm_supports FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert swarm supports"
  ON swarm_supports FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(session_id) >= 8);

-- ── SWARM PROMPTS ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS swarm_prompts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mission_key  text NOT NULL,
  team_side    text NOT NULL DEFAULT 'any' CHECK (team_side IN ('any','left','right')),
  prompt_text  text NOT NULL CHECK (char_length(prompt_text) BETWEEN 10 AND 1000),
  author_alias text NOT NULL DEFAULT 'Anonymous',
  votes        integer NOT NULL DEFAULT 0,
  session_id   text NOT NULL CHECK (char_length(session_id) >= 8),
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE swarm_prompts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read swarm prompts"
  ON swarm_prompts FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert swarm prompts"
  ON swarm_prompts FOR INSERT
  TO anon, authenticated
  WITH CHECK (char_length(prompt_text) >= 10 AND char_length(session_id) >= 8);

CREATE POLICY "Anyone can update swarm prompt votes"
  ON swarm_prompts FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- ── SITE STATS ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS site_stats (
  key    text PRIMARY KEY,
  value  bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE site_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read site stats"
  ON site_stats FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can upsert site stats"
  ON site_stats FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update site stats"
  ON site_stats FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Seed initial stat rows
INSERT INTO site_stats (key, value) VALUES
  ('total_votes', 0),
  ('total_reactions', 0),
  ('total_prompts', 0),
  ('total_supporters', 0)
ON CONFLICT (key) DO NOTHING;

-- Seed some starter forum posts so the feed feels alive
INSERT INTO forum_posts (author_alias, category, title, body, reaction_count, reply_count, is_ai_post) VALUES
  ('atlas_operator', 'showcase', 'How I automated my entire client onboarding in 3 days',
   'Sharing the exact swarm workflow I used to replace a 4-hour manual onboarding process with a 20-minute automated intake sequence. Discovery questionnaire, scope brief, contract summary, kickoff agenda — all AI-generated from a single intake form. The client literally said "this is the most professional onboarding I have ever experienced." Here is the full breakdown of each agent role and how I wired it together without writing a single line of code.',
   47, 23, false),
  ('strategist_kr', 'discussion', 'GPT vs Claude for business strategy: 6-month analysis',
   'After running both through 40+ strategy sessions, I have a fairly clear picture of where each model shines and where it falls flat. Claude wins on nuance, structured reasoning, and multi-step analysis. GPT wins on speed and breadth when you are iterating fast. But the real answer is neither — it is about knowing which tool to reach for and when. Breaking down my methodology, the 12 test categories, and what surprised me most about the results.',
   89, 61, false),
  ('meta_operator', 'strategy', 'Why I am betting on AI operators, not AI tools',
   'There is a difference between using AI and operating AI. Tools are commodities — they get cheaper, more capable, and more accessible every month. Operators are scarce — the ability to design systems, orchestrate agents, and translate business problems into automation architectures is a genuine skill gap. The money in 2026 is not in knowing which tool to use. It is in knowing how to build the stack that makes the tools irrelevant. Here is my framework for thinking about the operator advantage.',
   241, 103, false),
  ('prompt_craft', 'discussion', 'Prompt engineering is not dead — it evolved',
   'Everyone who said prompting does not matter was wrong. What died was naive one-shot prompting. What evolved is systems thinking applied to language model instruction. The operators getting the best results in 2026 are not typing better prompts — they are building prompt architectures. Multi-step reasoning chains. Role specialization. Output specification. Constraint stacking. I will walk through 5 structural patterns that separate amateur prompts from operator-grade prompt systems.',
   156, 57, false)
ON CONFLICT DO NOTHING;

-- Indexes for fast lookups
CREATE INDEX IF NOT EXISTS idx_forum_posts_created ON forum_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_forum_reactions_post ON forum_reactions(post_id);
CREATE INDEX IF NOT EXISTS idx_arena_votes_match ON arena_votes(match_key);
CREATE INDEX IF NOT EXISTS idx_swarm_prompts_mission ON swarm_prompts(mission_key, created_at DESC);
