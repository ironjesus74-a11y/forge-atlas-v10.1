/* =============================================================
   FORGE ATLAS — PREMIUM INTERACTIVE SYSTEM
   Command palette · Scroll reveals · Atlas AI · Local persistence
   ============================================================= */

'use strict';

/* ─────────────────────────────────────────────────────────────
   INIT
───────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  Nav.init();
  CommandPalette.init();
  Accordions.init();
  AtlasAI.init();
  AtlasID.init();
  Filters.init();
  Interactions.init();
  Reveals.init();
  Timers.init();
  CommandCenter.init();
});

/* ─────────────────────────────────────────────────────────────
   NAV
───────────────────────────────────────────────────────────── */
const Nav = {
  init() {
    this.hamburger  = document.querySelector('.nav-hamburger');
    this.drawer     = document.querySelector('.nav-drawer');
    this.markActive();

    if (this.hamburger && this.drawer) {
      this.hamburger.addEventListener('click', () => this.toggleDrawer());
      document.addEventListener('click', e => {
        if (!e.target.closest('.nav-bar') && !e.target.closest('.nav-drawer')) {
          this.closeDrawer();
        }
      });
    }

    // Sticky shadow
    window.addEventListener('scroll', () => {
      const bar = document.querySelector('.nav-bar');
      if (bar) bar.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  },

  toggleDrawer() {
    const open = this.drawer.classList.toggle('open');
    this.hamburger.setAttribute('aria-expanded', open);
  },

  closeDrawer() {
    this.drawer?.classList.remove('open');
    this.hamburger?.setAttribute('aria-expanded', 'false');
  },

  markActive() {
    const page = document.body.dataset.page || '';
    document.querySelectorAll('[data-nav-page]').forEach(el => {
      el.classList.toggle('active', el.dataset.navPage === page);
    });
  }
};

/* ─────────────────────────────────────────────────────────────
   COMMAND PALETTE
───────────────────────────────────────────────────────────── */
const COMMANDS = [
  { label: 'Home',            icon: '🏠', href: 'index.html',          category: 'Navigate' },
  { label: 'Arena',           icon: '⚔️', href: 'arena.html',           category: 'Navigate' },
  { label: 'Swarm Battles',   icon: '🔄', href: 'swarm.html',           category: 'Navigate' },
  { label: 'Dev Market',      icon: '🏪', href: 'market.html',          category: 'Navigate' },
  { label: 'Forge Feed',      icon: '💬', href: 'forum.html',           category: 'Navigate' },
  { label: 'Atlas ID',        icon: '🪪', href: 'atlas-id.html',        category: 'Navigate' },
  { label: 'Freelance Board', icon: '💼', href: 'freelance.html',       category: 'Navigate' },
  { label: 'Gallery',         icon: '🖼️', href: 'gallery.html',         category: 'Navigate' },
  { label: 'Premium Access',  icon: '⭐', href: 'access.html',          category: 'Navigate' },
  { label: 'Command Center',  icon: '🖥️', href: 'command-center.html',  category: 'Navigate' },
  { label: 'About',           icon: 'ℹ️', href: 'about.html',           category: 'Navigate' },
  { label: 'FAQ',             icon: '❓', href: 'faq.html',             category: 'Navigate' },
  { label: 'Contact',         icon: '✉️', href: 'contact.html',         category: 'Navigate' },
  { label: 'Save Atlas ID',   icon: '💾', action: 'saveAtlasID',        category: 'Actions'  },
  { label: 'Copy profile',    icon: '📋', action: 'copyProfile',        category: 'Actions'  },
];

const CommandPalette = {
  open: false,
  selected: 0,
  filtered: [...COMMANDS],

  init() {
    this.overlay = document.querySelector('.cmd-overlay');
    this.input   = document.querySelector('.cmd-input');
    if (!this.overlay) return;

    // Keyboard open
    document.addEventListener('keydown', e => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        this.toggle();
      }
      if (e.key === 'Escape' && this.open) this.close();
      if (this.open) {
        if (e.key === 'ArrowDown') { e.preventDefault(); this.move(1); }
        if (e.key === 'ArrowUp')   { e.preventDefault(); this.move(-1); }
        if (e.key === 'Enter')     { e.preventDefault(); this.execute(); }
      }
    });

    // Click outside closes
    this.overlay.addEventListener('click', e => {
      if (e.target === this.overlay) this.close();
    });

    // Trigger buttons
    document.querySelectorAll('[data-cmd-open]').forEach(btn => {
      btn.addEventListener('click', () => this.toggle());
    });

    // Input search
    this.input?.addEventListener('input', () => this.search(this.input.value));

    this.render();
  },

  toggle() { this.open ? this.close() : this.openPalette(); },

  openPalette() {
    this.open = true;
    this.overlay.classList.add('open');
    this.input?.focus();
    this.selected = 0;
    this.render();
  },

  close() {
    this.open = false;
    this.overlay.classList.remove('open');
    if (this.input) this.input.value = '';
    this.filtered = [...COMMANDS];
    this.render();
  },

  search(query) {
    const q = query.toLowerCase();
    this.filtered = q
      ? COMMANDS.filter(c => c.label.toLowerCase().includes(q) || c.category.toLowerCase().includes(q))
      : [...COMMANDS];
    this.selected = 0;
    this.render();
  },

  move(dir) {
    this.selected = Math.max(0, Math.min(this.filtered.length - 1, this.selected + dir));
    this.renderHighlight();
    document.querySelectorAll('.cmd-item')[this.selected]?.scrollIntoView({ block: 'nearest' });
  },

  execute() {
    const cmd = this.filtered[this.selected];
    if (!cmd) return;
    if (cmd.href)   window.location.href = cmd.href;
    if (cmd.action) {
      if (cmd.action === 'saveAtlasID')  AtlasID.save();
      if (cmd.action === 'copyProfile')  AtlasID.copy();
    }
    this.close();
  },

  render() {
    const results = document.querySelector('.cmd-results');
    if (!results) return;

    // Group by category
    const groups = {};
    this.filtered.forEach(cmd => {
      if (!groups[cmd.category]) groups[cmd.category] = [];
      groups[cmd.category].push(cmd);
    });

    let html = '';
    let idx = 0;
    Object.entries(groups).forEach(([cat, cmds]) => {
      html += `<div class="cmd-section-label">${cat}</div>`;
      cmds.forEach(cmd => {
        html += `
          <div class="cmd-item${idx === this.selected ? ' selected' : ''}" data-idx="${idx}" role="option">
            <div class="cmd-item-icon">${cmd.icon}</div>
            <span class="cmd-item-label">${cmd.label}</span>
            <span class="cmd-item-category">${cmd.category}</span>
          </div>`;
        idx++;
      });
    });

    results.innerHTML = html || '<div style="padding:1rem;color:var(--text-muted);font-size:.85rem;text-align:center;">No results</div>';

    results.querySelectorAll('.cmd-item').forEach(item => {
      item.addEventListener('click', () => {
        this.selected = parseInt(item.dataset.idx);
        this.execute();
      });
    });
  },

  renderHighlight() {
    document.querySelectorAll('.cmd-item').forEach((item, i) => {
      item.classList.toggle('selected', i === this.selected);
    });
  }
};

/* ─────────────────────────────────────────────────────────────
   ACCORDIONS
───────────────────────────────────────────────────────────── */
const Accordions = {
  init() {
    document.querySelectorAll('.accordion-trigger').forEach(btn => {
      btn.addEventListener('click', () => this.toggle(btn));
    });
  },

  toggle(btn) {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', !expanded);
    const body = btn.nextElementSibling;
    if (body) body.classList.toggle('open', !expanded);
  }
};

/* ─────────────────────────────────────────────────────────────
   ATLAS AI WIDGET
───────────────────────────────────────────────────────────── */
const ATLAS_RESPONSES = {
  default:       "I'm Atlas — your operator guide. Ask me about the arena, market, swarm missions, or backend roadmap.",
  arena:         "The Arena is an editorial AI battle theater. Six divisions — Debate, Code-Off, Roast, Strategy War Room, Image Duel, and Music Duel. Model ecosystems compete. Future: live Claude/GPT integration via Cloudflare Workers.",
  swarm:         "Swarm Battles feature AI teams executing structured missions. Strategists route, builders execute, critics review, closers deliver. Currently simulated. Future: real multi-agent orchestration.",
  market:        "The Dev Market sells automation kits, prompt systems, deployment blueprints, and operator tools. Manual fulfillment today. Future: automated via Cloudflare Workers + PayPal webhooks.",
  forum:         "Forge Feed is the operator community forum — arena talk, swarm strategy, automation threads. Demo content now. Future: real posts, user accounts, and Atlas AI auto-responses for unanswered threads.",
  atlasid:       "Atlas ID is your operator profile. Callsign, rank, specialty, badges, bio. Saves locally in your browser now. Future: cloud-synced profiles with global reputation scoring.",
  freelance:     "The Operator Board shows available services — automation setup, AI workflows, portfolio upgrades. Demo listings now. Future: integrated booking and payments.",
  gallery:       "The Gallery showcases concept art, system designs, and project builds. Submit your work in the future.",
  access:        "Premium Access supports development and unlocks future features. PayPal processes payments. Manual fulfillment for now.",
  faq:           "The FAQ covers everything: architecture, payments, backend roadmap, privacy, and honesty principles.",
  commandcenter: "Command Center is your operator dashboard. Deploy status, security checks, and platform metrics. Demo data today. Future: real auth and live metrics.",
  payment:       "Payments go through PayPal. Manual fulfillment for now. Future: automated Cloudflare Workers + PayPal webhook pipeline.",
  backend:       "Backend roadmap: Cloudflare Workers (API), D1 (database), KV (caching), R2 (storage), Claude API (AI), PayPal webhooks (payments).",
  honest:        "Forge Atlas is honest by design. What's real is labeled real. What's future is labeled future. Votes are local. Data stays in your browser. No fake live data.",
  automation:    "The long-term goal is selling automation. The market, freelance board, and backend roadmap all support this. Cloudflare Workers + Claude API = the automation engine.",
  podcast:       "The NotebookLM podcast introduction is a great idea — a premium audio brand layer that makes the platform feel alive and authoritative.",
  launch:        "Six months of work. A complete flagship platform. Static today, backend-ready tomorrow. The launch strategy is solid — ship the static foundation, add backend components one at a time.",
};

const AtlasAI = {
  init() {
    this.orb    = document.querySelector('.atlas-ai-orb');
    this.panel  = document.querySelector('.atlas-ai-panel');
    this.close  = document.querySelector('.atlas-ai-close');
    this.content = document.querySelector('.atlas-ai-content');

    if (!this.orb) return;

    this.orb.addEventListener('click', () => this.toggle());
    this.close?.addEventListener('click', () => this.closePanel());

    document.querySelectorAll('.atlas-prompt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.dataset.prompt;
        this.respond(ATLAS_RESPONSES[key] || ATLAS_RESPONSES.default);
      });
    });

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && this.panel?.classList.contains('open')) {
        this.closePanel();
      }
    });
  },

  toggle() {
    this.panel?.classList.toggle('open');
  },

  closePanel() {
    this.panel?.classList.remove('open');
  },

  respond(text) {
    if (!this.content) return;

    // Show typing indicator
    const typing = document.createElement('div');
    typing.className = 'atlas-ai-typing';
    typing.innerHTML = '<div class="atlas-ai-dot"></div><div class="atlas-ai-dot"></div><div class="atlas-ai-dot"></div>';
    this.content.appendChild(typing);
    this.content.scrollTop = this.content.scrollHeight;

    setTimeout(() => {
      typing.remove();
      const msg = document.createElement('div');
      msg.className = 'atlas-ai-msg';
      msg.textContent = text;
      this.content.appendChild(msg);
      this.content.scrollTop = this.content.scrollHeight;
    }, 900);
  }
};

/* ─────────────────────────────────────────────────────────────
   ATLAS ID BUILDER
───────────────────────────────────────────────────────────── */
const AtlasID = {
  init() {
    this.form = document.getElementById('atlas-id-form');
    if (!this.form) return;

    this.form.querySelectorAll('input,textarea,select').forEach(el => {
      el.addEventListener('input', () => this.updatePreview());
      el.addEventListener('change', () => this.updatePreview());
    });

    document.getElementById('atlas-id-save')?.addEventListener('click', () => this.save());
    document.getElementById('atlas-id-copy')?.addEventListener('click', () => this.copy());

    this.load();
    this.updatePreview();
  },

  getData() {
    if (!this.form) return {};
    return {
      callsign: this.form.querySelector('[name="callsign"]')?.value.trim()     || 'Operator',
      displayName: this.form.querySelector('[name="displayName"]')?.value.trim() || 'Your Name',
      rank: this.form.querySelector('[name="rank"]')?.value                    || 'Initiate',
      specialty: this.form.querySelector('[name="specialty"]')?.value          || 'Builder',
      bio: this.form.querySelector('[name="bio"]')?.value.trim()               || '',
    };
  },

  updatePreview() {
    const preview = document.getElementById('atlas-id-preview');
    if (!preview) return;
    const d = this.getData();

    preview.innerHTML = `
      <div class="card card-glow" style="border-color:var(--gold-dim);">
        <div class="card-header">
          <div>
            <div class="card-title">${sanitize(d.callsign)}</div>
            <div style="font-size:.8rem;color:var(--text-muted);margin-top:4px;">${sanitize(d.displayName)}</div>
          </div>
          <span class="badge badge-gold">${sanitize(d.rank)}</span>
        </div>
        <div class="card-body">
          <p style="margin-bottom:.5rem;font-size:.82rem;"><strong style="color:var(--text-secondary);">Specialty:</strong> ${sanitize(d.specialty)}</p>
          ${d.bio ? `<p style="font-size:.82rem;">${sanitize(d.bio)}</p>` : ''}
        </div>
      </div>`;
  },

  save() {
    try {
      localStorage.setItem('atlasID', JSON.stringify(this.getData()));
      showToast('Atlas ID saved to your browser.', 'success', 'Profile saved');
    } catch {
      showToast('localStorage unavailable.', 'error', 'Save failed');
    }
  },

  load() {
    if (!this.form) return;
    try {
      const saved = JSON.parse(localStorage.getItem('atlasID') || 'null');
      if (!saved) return;
      Object.entries(saved).forEach(([k, v]) => {
        const el = this.form.querySelector(`[name="${k}"]`);
        if (el) el.value = v;
      });
    } catch { /* silent */ }
  },

  copy() {
    const d = this.getData();
    const text = `${d.callsign} (${d.displayName}) · ${d.rank} · ${d.specialty}`;
    navigator.clipboard?.writeText(text)
      .then(() => showToast('Copied to clipboard.', 'success', 'Profile copied'))
      .catch(() => showToast('Could not copy.', 'error', 'Copy failed'));
  }
};

/* ─────────────────────────────────────────────────────────────
   FILTERS
───────────────────────────────────────────────────────────── */
const Filters = {
  init() {
    // Generic filter system using data-filter-group and data-filter-value
    document.querySelectorAll('[data-filter-btn]').forEach(btn => {
      btn.addEventListener('click', () => {
        const group = btn.dataset.filterGroup;
        const value = btn.dataset.filterBtn;

        // Update active state
        document.querySelectorAll(`[data-filter-group="${group}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Filter items
        document.querySelectorAll(`[data-filter-item="${group}"]`).forEach(item => {
          const match = value === 'all' || item.dataset.filterValue === value;
          item.style.display = match ? '' : 'none';
          if (match) item.classList.add('animate-fade-up');
        });
      });
    });

    // Product search
    const search = document.getElementById('product-search');
    if (search) {
      search.addEventListener('input', () => {
        const q = search.value.toLowerCase();
        document.querySelectorAll('[data-filter-item="product"]').forEach(item => {
          const name = item.dataset.filterValue?.toLowerCase() || '';
          const text = item.textContent.toLowerCase();
          item.style.display = (name.includes(q) || text.includes(q)) ? '' : 'none';
        });
      });
    }
  }
};

/* ─────────────────────────────────────────────────────────────
   INTERACTIONS (votes, reactions, forms)
───────────────────────────────────────────────────────────── */
const Interactions = {
  init() {
    // Vote buttons
    document.querySelectorAll('[data-vote]').forEach(btn => {
      btn.addEventListener('click', () => this.vote(btn));
    });

    // Support buttons
    document.querySelectorAll('[data-support]').forEach(btn => {
      btn.addEventListener('click', () => this.support(btn));
    });

    // Reaction buttons
    document.querySelectorAll('[data-reaction]').forEach(btn => {
      btn.addEventListener('click', () => this.react(btn));
    });

    // Contact form
    document.getElementById('contact-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const form = e.target;
      const name  = form.querySelector('[name="name"]')?.value.trim();
      const email = form.querySelector('[name="email"]')?.value.trim();
      const msg   = form.querySelector('[name="message"]')?.value.trim();
      if (!name || !email || !msg) {
        showToast('Please fill in all required fields.', 'error', 'Incomplete form');
        return;
      }
      showToast('Message received. We will respond within 24–48 hours.', 'success', 'Sent!');
      form.reset();
    });

    // Shop / inquiry buttons
    document.querySelectorAll('[data-shop]').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.dataset.shop;
        showToast(`Inquiry for "${item}" noted. Contact us to complete purchase.`, 'gold', 'Interest logged');
      });
    });
  },

  _store(key) {
    try { return JSON.parse(localStorage.getItem(key) || '{}'); }
    catch { return {}; }
  },

  _save(key, data) {
    try { localStorage.setItem(key, JSON.stringify(data)); } catch { /* silent */ }
  },

  vote(btn) {
    const id = btn.dataset.vote;
    const data = this._store('fa_votes');
    data[id] = (data[id] || 0) + 1;
    this._save('fa_votes', data);
    const counter = btn.querySelector('.vote-count');
    if (counter) counter.textContent = data[id];
    btn.classList.add('voted');
    showToast('Vote recorded locally.', 'success', 'Voted!');
  },

  support(btn) {
    const id = btn.dataset.support;
    const data = this._store('fa_support');
    data[id] = (data[id] || 0) + 1;
    this._save('fa_support', data);
    const counter = btn.querySelector('.support-count');
    if (counter) counter.textContent = data[id];
    btn.classList.add('voted');
    showToast('Support registered.', 'success', 'Supported!');
  },

  react(btn) {
    const id = btn.dataset.reaction;
    const type = btn.dataset.reactionType || 'like';
    const data = this._store('fa_reactions');
    const key = `${id}_${type}`;
    data[key] = (data[key] || 0) + 1;
    this._save('fa_reactions', data);
    const counter = btn.querySelector('.reaction-count');
    if (counter) counter.textContent = data[key];
    btn.classList.add('voted');
  }
};

/* ─────────────────────────────────────────────────────────────
   SCROLL REVEALS
───────────────────────────────────────────────────────────── */
const Reveals = {
  init() {
    if (!('IntersectionObserver' in window)) return;

    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
  }
};

/* ─────────────────────────────────────────────────────────────
   TIMERS
───────────────────────────────────────────────────────────── */
const Timers = {
  init() {
    document.querySelectorAll('[data-timer]').forEach(el => {
      const secs = parseInt(el.dataset.timer) || 480;
      this.start(el, secs);
    });
  },

  start(el, total) {
    let remaining = total;
    const tick = () => {
      const m = Math.floor(remaining / 60);
      const s = remaining % 60;
      el.textContent = `${m}:${s.toString().padStart(2,'0')}`;
      if (remaining > 0) {
        remaining--;
        setTimeout(tick, 1000);
      } else {
        el.textContent = '0:00';
        el.style.color = 'var(--error)';
      }
    };
    tick();
  }
};

/* ─────────────────────────────────────────────────────────────
   COMMAND CENTER (panel switcher)
───────────────────────────────────────────────────────────── */
const CommandCenter = {
  init() {
    document.querySelectorAll('[data-panel-btn]').forEach(btn => {
      btn.addEventListener('click', () => this.show(btn.dataset.panelBtn));
    });
  },

  show(id) {
    document.querySelectorAll('[data-panel-btn]').forEach(b => {
      b.classList.toggle('active', b.dataset.panelBtn === id);
    });
    document.querySelectorAll('[data-panel]').forEach(p => {
      p.style.display = p.dataset.panel === id ? 'block' : 'none';
    });
  }
};

/* ─────────────────────────────────────────────────────────────
   PAYPAL
───────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof window.paypal !== 'undefined') {
    const container = document.getElementById('paypal-button-container');
    if (container) {
      try {
        window.paypal.HostedButtons({ hostedButtonId: 'UTLCRYVANMMYU' })
          .render('#paypal-button-container');
      } catch (e) {
        console.warn('PayPal render error:', e);
      }
    }
  }
});

/* ─────────────────────────────────────────────────────────────
   UTILITIES
───────────────────────────────────────────────────────────── */
function sanitize(text) {
  const div = document.createElement('div');
  div.textContent = String(text || '');
  return div.innerHTML;
}

function showToast(message, type = 'gold', title = '') {
  let rack = document.querySelector('.toast-rack');
  if (!rack) {
    rack = document.createElement('div');
    rack.className = 'toast-rack';
    document.body.appendChild(rack);
  }

  const icons = { success:'✓', error:'✕', gold:'⚡', cyan:'◈' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-icon" style="color:var(--${type === 'success' ? 'success' : type === 'error' ? 'error' : type === 'cyan' ? 'cyan' : 'gold-primary'})">${icons[type] || '⚡'}</div>
    <div class="toast-body">
      ${title ? `<div class="toast-title">${sanitize(title)}</div>` : ''}
      <div class="toast-msg">${sanitize(message)}</div>
    </div>
    <button class="toast-close" aria-label="Dismiss">&times;</button>`;

  rack.appendChild(toast);
  toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-24px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4200);
}

/* Global exports */
window.showToast = showToast;
window.AtlasAI   = AtlasAI;
window.AtlasID   = AtlasID;
