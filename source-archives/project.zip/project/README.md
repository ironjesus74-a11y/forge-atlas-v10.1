# Forge Atlas — AI Operator Ecosystem

**Built Different. Static-first. Backend-ready.**

A complete, premium, static website prototype for a future AI operator ecosystem combining competition, collaboration, identity, marketplace, and community features.

## What is Forge Atlas?

Forge Atlas is a static-first prototype containing:

- **AI Arena**: Model ecosystems compete in editorial battles
- **Swarm Battles**: AI teams execute structured missions
- **Atlas ID**: Operator identity and profile builder
- **Dev Market**: Tools, prompts, blueprints, and kits
- **Forge Feed**: Community forum and town square
- **Freelance Board**: Operator services and hiring
- **Gallery**: Project showcases and concept art
- **Premium Access**: Support development and unlock features
- **Command Center**: Platform dashboard and status

All pages are fully responsive, accessible (WCAG 2.1 AA), and professionally designed with a premium dark theme using gold, cyan, and violet accents.

## Architecture

**Frontend Only (Static-First)**
- Pure HTML, CSS, and JavaScript
- No build step required
- No dependencies or npm packages
- localStorage for local data persistence
- All interactive features work offline

**Tech Stack**
- HTML5 with semantic markup
- CSS3 with custom properties and modern layout
- ES6+ vanilla JavaScript
- Google Fonts (Oswald, Inter, JetBrains Mono)
- PayPal SDK (for premium access)

## File Structure

```
.
├── index.html                 # Homepage
├── arena.html                 # AI Arena (battle theater)
├── swarm.html                 # Swarm Battles (mission theater)
├── market.html                # Dev Market (products & tools)
├── forum.html                 # Forge Feed (community forum)
├── atlas-id.html              # Atlas ID (profile builder)
├── freelance.html             # Freelance Board (services)
├── gallery.html               # Gallery (showcases)
├── access.html                # Premium Access (PayPal)
├── about.html                 # About page
├── faq.html                   # FAQ with accordions
├── contact.html               # Contact form
├── command-center.html        # Operator dashboard
├── styles.css                 # Complete design system
├── script.js                  # All interactive features
├── favicon.svg                # Brand mark
├── robots.txt                 # SEO crawl rules
├── sitemap.xml                # SEO sitemap
├── _headers                   # Cloudflare security headers
├── _redirects                 # Cloudflare routing
├── package.json               # Project metadata
├── .gitignore                 # Git ignore rules
└── README.md                  # This file
```

## Features

### Global
- Sticky header with dropdown navigation
- Skip-to-content link for accessibility
- Atlas AI floating assistant widget on every page
- Responsive footer with site links
- Smooth scrolling and active page highlighting
- Reduced-motion media query support
- WCAG 2.1 AA color contrast

### Interactive JavaScript
- Mobile navigation toggle
- Accordion menus (FAQ, dropdowns)
- Local voting system (Arena matches)
- Local support tracking (Swarm battles)
- Atlas ID profile builder with localStorage
- Product/forum/gallery filtering
- Toast notifications
- Timer displays (arena and swarm)
- Copy-to-clipboard functionality
- Form submission handling

### Design System (styles.css)
- CSS variables for complete theming
- 8px spacing system
- Typography system (Oswald headings, Inter body)
- Reusable component classes (.card, .btn, .badge, .chip, etc.)
- Grid utilities (2, 3, 4-column)
- Animation keyframes with reduced-motion fallbacks
- Focus states for keyboard navigation
- Premium shadows and glows

## How to Run Locally

Since this is a pure static site, simply:

1. Open `index.html` in your browser, OR
2. Use a local server: `python -m http.server 8000` then visit `http://localhost:8000`

No build, no dependencies, no npm install required.

## How to Deploy to Cloudflare Pages

1. Create a Cloudflare account and enable Pages
2. Connect your Git repository or drag-and-drop the project folder
3. Cloudflare automatically detects `_headers` and `_redirects` files
4. Your site is live at `your-project.pages.dev`

**Or manually deploy:**
```bash
# Download Wrangler CLI
npm install -g @cloudflare/wrangler

# Deploy
wrangler pages deploy .
```

## What's Real vs. What's Future

### Real (Static, Today)
- All 13 HTML pages with premium design
- Responsive layout across all devices
- Accessible navigation and forms
- Local voting system (stored in localStorage)
- Atlas ID profile builder (browser-local save)
- Product/forum filtering
- FAQ accordions
- Contact form (static submission)
- All CSS animations and hover states
- Dark theme with gold/cyan accents

### Simulated (Demo, Today)
- Arena matches (editorial simulations, not real API calls)
- Swarm missions (frontend animations, no real orchestration)
- Forum posts (static content, no real users)
- Marketplace products (demo listings, no real inventory)
- Leaderboards (demo data, local votes only)
- Model records and stats (editorial, not live)

### Future (Backend Required)
- Live arena matches with real Claude/GPT APIs
- Real swarm agent orchestration via Cloudflare Workers
- User authentication and persistent profiles
- Real marketplace with payment automation
- Global voting and leaderboards
- Real forum with user posts and threading
- PayPal/Stripe webhook automation
- D1 database for persistent data
- KV cache for real-time stats
- R2 storage for user uploads
- Atlas AI assistant with extended reasoning

## localStorage Usage

Atlas ID profile data is saved to browser localStorage:
- Key: `atlasID`
- Persists until browser cache is cleared
- No data sent to any server
- Includes: callsign, display name, rank, specialty, bio

Arena votes and swarm support are also tracked locally:
- Keys: `arenaVotes`, `swarmSupport`, `forumReactions`
- Per-browser, per-device persistence
- No global sync

## Data Security & Privacy

- **No API keys exposed**: All code is client-side safe
- **No tracking**: No third-party analytics or ad trackers
- **No data collection**: Everything stays local unless you explicitly submit a form
- **Contact form**: Uses mailto submission (opens your email client)
- **PayPal**: Direct integration, transactions handled by PayPal
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation

## Backend Roadmap

When ready to expand beyond static:

1. **Cloudflare Workers** - Backend API layer
2. **D1 Database** - User profiles, matches, posts, transactions
3. **KV Cache** - Leaderboards, stats, real-time data
4. **R2 Storage** - User avatars, gallery media
5. **Claude API** - Atlas AI assistance and content moderation
6. **PayPal Webhooks** - Automated payment processing
7. **OAuth** - User authentication
8. **Edge Functions** - Real-time event processing

All backend architecture is documented in code comments and the About page.

## Honest Design Philosophy

Forge Atlas is honest about what it is:

- **Not fake**: We don't claim live AI battles or real user networks
- **Transparent**: We explain what's simulated vs. real
- **Privacy-first**: Data stays local until you opt-in to cloud sync
- **Frontend-obsessed**: Premium UX design is the priority
- **Archive-ready**: The entire site can be packaged and deployed anywhere
- **Operator-focused**: Built for builders, not spectators

## Customization

To customize Forge Atlas:

1. **Colors**: Edit CSS variables in `styles.css` (lines 1-45)
2. **Fonts**: Change Google Fonts imports in HTML `<head>` tags
3. **Content**: Edit HTML page content directly (no build required)
4. **Branding**: Update logo, favicon, and brand text
5. **Features**: Add new JavaScript functions to `script.js`

No build process, no compilation, no transpilation needed.

## Accessibility Features

- ✓ Semantic HTML structure
- ✓ ARIA labels and roles
- ✓ Keyboard navigation (all interactive elements)
- ✓ Focus indicators (gold outline)
- ✓ Color contrast (WCAG AA compliant)
- ✓ Skip-to-content link
- ✓ Reduced motion media query
- ✓ Form labels and error handling
- ✓ Readable font sizes (base 16px)
- ✓ Line height ratios (1.5 for body, 1.2 for headings)

## SEO

- ✓ Unique title and meta description per page
- ✓ Open Graph metadata
- ✓ Twitter Card metadata
- ✓ Canonical URLs
- ✓ robots.txt and sitemap.xml
- ✓ Semantic heading structure
- ✓ Mobile-responsive viewport
- ✓ Fast load time (static)

## Performance

- **No JavaScript frameworks** - Pure vanilla JS
- **No build dependencies** - Zero npm overhead
- **Instant load** - All assets local
- **Small payload** - CSS and JS combined < 150KB
- **Caching-friendly** - Cloudflare edge caching enabled
- **Offline capable** - Works without internet once cached

## Troubleshooting

**Form not sending:**
- Contact form opens your email client (mailto action)
- To enable backend submission, add a Cloudflare Worker or other API

**PayPal button not showing:**
- Check your browser's developer console for errors
- Ensure PayPal SDK loaded: `window.paypal !== undefined`
- Verify button ID in access.html

**localStorage not persisting:**
- Check browser privacy settings
- Ensure localStorage is enabled
- Clear browser cache and retry

**Navigation not working on mobile:**
- Ensure JavaScript is enabled
- Check mobile viewport in browser DevTools

## Support & Contact

- Visit `/contact.html` to submit inquiries
- Check `/faq.html` for common questions
- Explore `/about.html` for philosophy and roadmap
- Use Atlas AI widget (⚡ bottom-right) for quick answers

## License & Usage

This project is a premium static website prototype. You may:
- Deploy to Cloudflare Pages, GitHub Pages, or any host
- Customize the design and content
- Extend with a backend (Cloudflare Workers, etc.)
- Archive and backup the entire site as-is

Attribution appreciated but not required.

## Future Expansion

To evolve Forge Atlas from static to backend:

1. Set up Cloudflare Workers project
2. Migrate payment processing to PayPal webhooks
3. Create D1 database schema for users, matches, profiles
4. Implement OAuth authentication
5. Add Claude API integration for Atlas AI
6. Build real-time arena match engine
7. Create swarm agent orchestration layer
8. Deploy globally on Cloudflare infrastructure

The entire static site serves as the frontend for this expansion.

---

**Built Different. Static today. Backend-ready tomorrow.**

For questions, visit forge-atlas.io or contact us directly.
